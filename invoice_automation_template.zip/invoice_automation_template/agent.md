# Agent Prompts — Invoice Automation

When the user says a shorthand command (extract email / extract invoice / extract card / extract all),
run the exact prompt below for that command. Always read `system.md` in this folder first for
field mappings, extraction patterns, and known issues before executing.

---

## Command: `extract email`

**Trigger phrases:** "extract email", "download invoices", "fetch emails", "run email download"

**Full prompt to execute:**

> Read the CONFIG sheet from /Invoices/Invoice_Automation_Config.xlsx.
> For each row where Active = Y:
> 1. Connect to Gmail and search for emails matching the From Email, Subject Keyword, Body Keywords, and date range (Date From → Date To) specified in that CONFIG row.
> 2. For each matching email, identify the Invoice Type from the CONFIG row.
> 3. Download the invoice:
>    - For PDF / EXCEL types: download the email attachment directly.
>    - For LINK_PORTAL / LINK_PORTAL_PWD types: use Claude in Chrome to navigate the portal link in the email, follow the Portal / Link Notes instructions, and click the Download Button Text button.
> 4. Save each file to the Download Folder Path specified in the CONFIG row, using the File Prefix Pattern: `{Company}_{Supplier}_{Month}` where Month = abbreviated month + year (e.g. May2026).
> 4b. **Dedup check**: Before downloading, load DOWNLOAD_LOG from Invoice_Logs.xlsx. If a row exists where Gmail Message ID (col 14) matches this email's Message ID AND Status (col 12) = SUCCESS → log as `SKIPPED - already downloaded` and move to the next email. Do NOT re-download.
>
> 5. Log every download attempt to the DOWNLOAD_LOG tab in **Invoice_Logs.xlsx** with columns:
>    Run Timestamp | Config Row # | Company | Supplier | Email From | Email Subject | Email Date | Invoice Type | Original Filename | Saved Filename | Saved To Folder | Status | Gmail Thread ID | Gmail Message ID
> 5b. **Auto password removal**: After saving the file, check CONFIG col U (Remove Password). If Y — open the saved file with the password from col J and re-save without password using `pikepdf`. Log alongside the download row.
> 6. Status values: `SUCCESS`, `SUCCESS + PASSWORD REMOVED`, `NO MATCH - no email found`, `FAILED - download error`.
> 7. At the end, report how many CONFIG rows were processed, how many emails matched, how many files were downloaded successfully, and how many failed.

---

## Command: `extract invoice`

**Trigger phrases:** "extract invoice", "process invoices", "run invoice extraction"

**Full prompt to execute:**

> Read the CONFIG sheet from /Invoices/Invoice_Automation_Config.xlsx.
> Then process each file in the /Invoices/Inbox/ folder one by one:
>
> 1. Match the file to its CONFIG row using the filename prefix ({Company}_{Supplier} portion).
> 2. Check the Supplier/Vendor name in the matched CONFIG row — if the last 2 characters are 'cc' (case insensitive), SKIP this file — it will be handled by the Card Statement extraction prompt. Log as SKIPPED in EXTRACTION_LOG.
> 3. **Duplicate check**: Before extracting, load EXTRACTION_LOG from Invoice_Logs.xlsx. If a row exists where File Name (col 5) matches this filename AND Outcome (col 12) = SUCCESS → set a `suspect_duplicate = True` flag. Do NOT skip — always extract (file may have been manually added).
> 4. Open the file using the Invoice Type and Password from the matched CONFIG row.
> 5. Extract these fields: Invoice Number, Invoice Date, Supplier Name, Description, Currency, Subtotal (excl tax), Tax Amount, Total Amount.
> 5. Write extracted data as a new row in the DATA tab — include Company name, Supplier name, Config Row #, file name, file path, and a Remarks column. If `suspect_duplicate = True`, set Remarks = `_suspect duplicate`.
> 6. Log outcome in EXTRACTION_LOG tab with columns: Run Timestamp | Config Row # | Company | Supplier | File Name | Invoice Type | Invoice Date | Supplier Name (from doc) | Tax Amount | Amount (excl tax) | Total Amount | Outcome | Moved To. If `suspect_duplicate = True`, set Outcome = `SUCCESS (suspect duplicate)`.
> 7. If extraction succeeds — move file from /Invoices/Inbox/ to /Invoices/Recorded/. Set Outcome = SUCCESS, Moved To = /Recorded/.
> 8. If extraction fails — move file to /Invoices/Error/ and log Error Type, Error Detail, Config Column to Fix, and Suggested Fix in ERROR_LOG. Set Status = Pending Fix. Set Outcome = FAILED, Moved To = /Error/.
> 9. Do not stop on error — continue processing remaining files.
> 10. At the end, report how many files were processed, how many succeeded, how many skipped (cc), and how many failed.

---

## Command: `extract card`

**Trigger phrases:** "extract card", "process card statements", "run card extraction", "extract credit card"

**Full prompt to execute:**

> Read the CONFIG sheet from /Invoices/Invoice_Automation_Config.xlsx.
> Then process each file in the /Invoices/Inbox/ folder one by one:
>
> 1. Match the file to its CONFIG row using the filename prefix ({Company}_{Supplier} portion).
> 2. Check the Supplier/Vendor name in the matched CONFIG row — if the last 2 characters are NOT 'cc' (case insensitive), SKIP this file — it is a regular invoice handled separately. Log as SKIPPED in EXTRACTION_LOG.
> 3. **Duplicate check**: Before extracting, load EXTRACTION_LOG from Invoice_Logs.xlsx. If a row exists where File Name (col 5) matches this filename AND Outcome (col 12) = SUCCESS → set a `suspect_duplicate = True` flag. Do NOT skip — always extract (file may have been manually added).
> 4. Open the file using the Invoice Type and Password from the matched CONFIG row.
> 5. Extract these fields: Card Number (last 4 digits if full number not shown), Statement Date, Period / Month, Due Date, Minimum Due Amount, Total Due Amount, Currency.
> 5. Write extracted data as a new row in the DATACARD tab — include Company name, Vendor Name, Config Row #, file name, file path, and a Remarks column. If `suspect_duplicate = True`, set Remarks = `_suspect duplicate`.
> 6. Log outcome in EXTRACTION_LOG tab with columns: Run Timestamp | Config Row # | Company | Supplier | File Name | Invoice Type | Invoice Date (use Statement Date) | Supplier Name (from doc) | Tax Amount | Amount (excl tax) | Total Amount (use Total Due) | Outcome | Moved To. If `suspect_duplicate = True`, set Outcome = `SUCCESS (suspect duplicate)`. Use 'DATACARD' in the Moved To column on success.
> 7. If extraction succeeds — move file from /Invoices/Inbox/ to /Invoices/cardextracted/. Set Outcome = SUCCESS.
> 8. If extraction fails — move file to /Invoices/Error/ and log Error Type, Error Detail, Config Column to Fix, and Suggested Fix in ERROR_LOG. Set Status = Pending Fix.
> 9. Do not stop on error — continue processing remaining files.
> 10. At the end, report how many card statements were processed, succeeded, skipped (non-cc), and failed.

---

## Command: `remove password`

**Trigger phrases:** "remove password", "stri