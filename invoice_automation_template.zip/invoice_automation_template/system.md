# System Reference — Invoice Automation Workspace

## Config Sheet Column Mapping

| Column | Field | Notes |
|---|---|---|
| A | Row # | Unique config row number |
| B | Company Name | e.g. SHOUKATH, Ayur Care Relax Center |
| C | Supplier / Vendor | Last 2 chars = 'cc' → card statement |
| D | From Email | Gmail sender filter |
| E | Subject Keyword | Gmail subject filter |
| F | Body Keywords | Comma-separated, OR logic |
| G | Date From | Search start date (DD/MM/YYYY) |
| H | Date To | Search end date (DD/MM/YYYY) |
| I | Invoice Type | See types below |
| J | File Password | Password for protected files |
| K | Portal / Link Notes | Instructions for LINK_PORTAL types |
| L | Download Button Text | Button label for Chrome navigation |
| M | Download Folder Path | Where to save downloaded files |
| N | File Prefix Pattern | `{Company}_{Supplier}_{Month}` |
| O | Last Known Type | For reference |
| P | Extraction Hint | e.g. "Summary sheet, cols A-F" |
| Q | Currency | AED, USD, etc. |
| R | Active (Y/N) | Only Y rows are processed |
| S | Last Updated | Date of last config change |
| T | Notes / Change Log | Free text |
| U | Remove Password (Y/N) | Y = strip password after download and save clean file in place |

---

## Invoice Types

| Type | Meaning |
|---|---|
| `PDF` | Plain PDF attachment — no password |
| `PDF_PWD` | Password-protected PDF attachment |
| `EXCEL` | Plain Excel attachment — no password |
| `EXCEL_PWD` | Password-protected Excel attachment |
| `LINK_DIRECT` | Email contains a direct download URL |
| `LINK_PORTAL` | Email link → portal page with download button (no login) |
| `LINK_PORTAL_PWD` | Portal download + file is password protected |
| `IMAGE` | Invoice sent as JPG/PNG — OCR extraction |
| `MIXED` | Check attachment first, fallback to link |

---

## Supplier Routing Rule

```
last 2 chars of Supplier/Vendor (case-insensitive) == 'cc'
  → Credit Card Statement  → DATACARD tab → /cardextracted/
  → else Regular Invoice   → DATA tab     → /Recorded/
```

**Examples:**
- `ENBDNOONONECC` → ends `cc` → card statement ✓
- `Al Shifa Trading LLC` → ends `LC` → regular invoice ✓
- `Gulf Supplies FZE` → ends `ZE` → regular invoice ✓

---

## Extracted Fields by Type

### Regular Invoice (DATA tab)
| Field | Source |
|---|---|
| Entry # | Auto-increment |
| Extraction Date | Run timestamp |
| Company | From CONFIG col B |
| Supplier Name (from doc) | Read from document |
| Invoice Number | Read from document |
| Invoice Date | Read from document |
| Period / Month | Read from document |
| Description | Read from document |
| Currency | From CONFIG col Q |
| Subtotal (excl tax) | Read from document |
| Tax Amount | Read from document |
| Total Amount | Read from document |
| File Name | Actual filename |
| Source File Path | Full path |
| Config Row # | From CONFIG col A |

### Card Statement (DATACARD tab)
| Field | Source |
|---|---|
| Entry # | Auto-increment |
| Extraction Date | Run timestamp |
| Config Row # | From CONFIG col A |
| Company | From CONFIG col B |
| Supplier / Vendor | From CONFIG col C |
| Card Last 4 | Read from document |
| Statement Date | Read from document |
| Statement Period | Read from document |
| Due Date | Read from document |
| Min Due (AED) | Read from document |
| Total Due (AED) | Credit Limit − Available Credit |
| Currency | From CONFIG col Q |
| File Name | Actual filename |
| File Path | Full path |

---

## EXTRACTION_LOG Columns
`Run Timestamp | Config Row # | Company | Supplier | File Name | Invoice Type | Invoice Date | Supplier Name (from doc) | Tax Amount | Amount (excl tax) | Total Amount | Outcome | Moved To`

- Outcome values: `SUCCESS`, `FAILED`, `SKIPPED - non-CC supplier`, `SKIPPED - CC supplier`, `SKIPPED - already extracted`
- Moved To values: `DATACARD`, `DATA`, `/Recorded/`, `/cardextracted/`, `/Error/`

## Deduplication Logic

### extract email — skip already-downloaded emails
Before downloading any attachment, Claude checks the DOWNLOAD_LOG for a row where:
- `Gmail Message ID` (col 14) matches the current email's Message ID **AND**
- `Status` (col 12) = `SUCCESS`

If found → log as `SKIPPED - already downloaded` and move on. This means re-running `extract email` on the same date range is safe — only new emails get downloaded.

**DOWNLOAD_LOG extra columns (cols 13-14):**

| Col | Field | Value |
|---|---|---|
| 13 | Gmail Thread ID | e.g. `19e1dfbfa6f22eb1` |
| 14 | Gmail Message ID | e.g. `19e1dfbfa6f22eb1` |

### extract card / extract invoice — flag suspect duplicates (never skip)
Files in Inbox may have been placed there manually (not downloaded via email), so extraction
never skips — every file in Inbox is always processed.

However, before extracting, Claude checks EXTRACTION_LOG for a row where:
- `File Name` (col 5) matches the current filename **AND**
- `Outcome` (col 12) = `SUCCESS`

If found → extract as normal, but append `_suspect duplicate` to the `Remarks` column of
the new DATACARD / DATA row, and set EXTRACTION_LOG Outcome = `SUCCESS (suspect duplicate)`.
This lets you review and delete the duplicate row manually if needed.

---

## ERROR_LOG Columns
`Timestamp | Config Row # | Company | Supplier | File Name | Invoice Type | Error Type | Error Detail | Config Column to Fix | Suggested Fix | Status | Retry Attempted | Retry Timestamp | Retry Outcome | Notes`

- Status: `Pending Fix` (default on failure)

---

## Remove Password — How It Works

Library: `pikepdf`

```python
# Open with password, save without — one step
with pikepdf.open(file_path, password=password) as pdf:
    pdf.save(file_path)   # overwrites in place, no password
```

- Works for PDF_PWD and LINK_PORTAL_PWD types
- Does NOT work for EXCEL_PWD — use openpyxl with password instead
- File size stays roughly the same (may be slightly larger due to re-serialization)
- Run order: `remove password` runs on files already in `/Inbox/`. Can also run automatically at end of `extract email` if CONFIG col U = Y.
- If removal fails (wrong password), file is left unchanged and error is logged

---

## Known Extraction Pattern — Emirates NBD CC Statement (PDF_PWD)

Library: `pikepdf` (decrypt) + `pdfminer` (text extract)

Key extraction logic:
- **Card last 4**: regex `\d{4} XXXX XXXX (\d{4})`
- **Statement period**: regex `\d{1,2}-\w{3}-\d{2,4} to \d{1,2}-\w{3}-\d{2,4}`
- **Statement date**: first `DD/MM/YYYY` date in text
- **Due date**: second `DD/MM/YYYY` date in text
- **Min due**: line immediately after due date line
- **Total due**: `Credit Limit − Available Credit` (lines 13 and 15 of extracted text)

Password format (ENBD): first 4 chars of name (caps) + DDMM of DOB
Example: `SHOU1401` = SHOU + 14th Jan

---

## Two-File Architecture

| File | Path | Who writes | Purpose |
|---|---|---|---|
| `Invoice_Automation_Config.xlsx` | `C:\claude\invoices\configs\` | **User only** | CONFIG rules — Claude reads only |
| `Invoice_Logs.xlsx` | `C:\claude\invoices\` | **Claude only** | All logs and extracted data |

**Why separate folders?** The Windows/Linux FUSE mount corrupts any `.xlsx` file once Claude writes to it — subsequent user saves from Excel are invisible to Claude (mount serves stale cached version). Keeping the config in `C:\claude\invoices\configs\` (a folder Claude never writes to) ensures Claude always sees the user's latest saved version.

---

## Known Issue — Mount Write Corruption

The Windows SMB/FUSE mount corrupts `.xlsx` ZIP structure whenever:
- Claude writes a file that was previously written by Claude, OR
- A file is written by Claude and then later re-saved by Excel (or vice versa)

**Root cause:** The mount page cache diverges after mixed read/write from both sides.

**Permanent fix:** Two-file architecture (see above). Claude never writes to the user's config file.

**Write rule for Claude (always apply):**
```python
wb.save('/tmp/output.xlsx')                            # 1. Save to /tmp
subprocess.run(['cp', '/tmp/output.xlsx', LOG_PATH])  # 2. cp to mount (Invoice_Logs.xlsx only)
```

**Read rule for Claude:**
- Always read `Invoice_Automation_Config.xlsx` directly from the mount — it is user-owned and never written by Claude, so it stays valid.
- Never read `Invoice_Logs.xlsx` for config data — it is write